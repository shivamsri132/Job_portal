/**
 * 
 */
package com.baeldung.spring.dao;

/**
 * @author amayd
 *
 */
public interface UserDao {

}
